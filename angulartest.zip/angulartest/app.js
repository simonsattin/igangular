var app = angular.module('igApp', []);
app.controller('IGAppController', function($scope,$http, $q) {

  $scope.gridOptions = {
        enableSorting: true,
        columnDefs: [
          { name:'firstName', field: 'first-name' },
          { name:'1stFriend', field: 'friends[0]' },
          { name:'city', field: 'address.city'},
          { name:'getZip', field: 'getZip()', enableCellEdit:false}
        ],
        data : [      {
                           "first-name": "Cox",
                           "friends": ["friend0"],
                           "address": {street:"301 Dove Ave", city:"Laurel", zip:"39565"},
                           "getZip" : function() {return this.address.zip;}
                       }
                   ]
      };

  var urlRoot = "https://api.ig.com/gateway/deal";
  var lsendpoint, accountid, account_token, client_token, apikey;

  $scope.username = 'SHN22';
  $scope.password = 'darcyB#o?23';
  $scope.apikey = 'fd3e7ec86cb96ad3d1e4aa13302ca9b14f337547';
  $scope.watchlists = [];

  $scope.login = function() {

    var identifier = $scope.username;
    var password = $scope.password;
    apikey = $scope.apikey;

    $http({
      method: 'POST',
      data: {
          "identifier": "SHN22",
          "password": "darcyB#o?23",
          "encryptedPassword": null
      },
      url: urlRoot + "/session",
      headers: {
          "Content-Type": "application/json; charset=UTF-8",
          "Accept": "application/json; charset=UTF-8",
          "X-IG-API-KEY": apikey,
          "Version": "2"
       }
    }).then(function(response) {
        console.log('Success');

        client_token = response.headers('CST');
        console.log('CST: ' + client_token);

        account_token = response.headers('X-SECURITY-TOKEN');
        console.log('X-SECURITY-TOKEN: ' + account_token);

        onLoggedInToServer();

      }, function(response) {
        alert('Failed: ' + response);
      });
  };

  $scope.refreshPositions = function() {
    getPositions();
  };

  function handleerror(response){
    alert('ERROR:' + response);
  }

  function loginToServer(response) {

      var key = response.data.encryptionKey;
      var timestamp = response.data.timeStamp;

      var asn, tree,
      rsa = new pidCrypt.RSA(),
      decodedKey = pidCryptUtil.decodeBase64(key);

      asn = pidCrypt.ASN1.decode(pidCryptUtil.toByteArray(decodedKey));
      tree = asn.toHexTree();

      rsa.setPublicKeyFromASN(tree);

      var encryptedpassword = pidCryptUtil.encodeBase64(pidCryptUtil.convertFromHex(rsa.encrypt($scope.password += '|' + timestamp)));

      console.log("Encrypted password " + encryptedpassword);

      var bodyParams = {};
      bodyParams["identifier"] = "SHN22";
      bodyParams["password"] = "darcyB#o?23";
      //bodyParams["encryptedPassword"] = true;
      bodyParams["encryptedPassword"] = null;
      var body = JSON.stringify(bodyParams);

      var loginrequest = $http({
        method: 'POST',
        data: {
            "identifier": "SHN22",
            "password": "darcyB#o?23",
            "encryptedPassword": null
        },
        url: urlRoot + "/session",
        headers: {
            "Content-Type": "application/json; charset=UTF-8",
            "Accept": "application/json; charset=UTF-8",
            "X-IG-API-KEY": $scope.apikey,
            "Version": "2"
         },
      });

      loginrequest.then(onLoggedInToServer,handleerror);
  }

  function onLoggedInToServer(){
    getWatchlists();
    getPositions();
  }

  function getWatchlists(){
    $http({
      method: 'GET',
      url: urlRoot + "/watchlists",
      headers: {
          "X-IG-API-KEY": apikey,
          "Content-Type": "application/json; charset=UTF-8",
          "Accept": "application/json; charset=UTF-8",
          "X-SECURITY-TOKEN": account_token,
          "CST": client_token
      },
      data: ''
    }).then(function(response) {

        $scope.watchlists = response.data.watchlists;      

      }, function(response) {
        alert('Failed: ' + response);
      });
  }

  function getPositions(){
    $http({
      method: 'GET',
      url: urlRoot + "/positions",
      headers: {
          "X-IG-API-KEY": apikey,
          "Content-Type": "application/json; charset=UTF-8",
          "Accept": "application/json; charset=UTF-8",
          "X-SECURITY-TOKEN": account_token,
          "CST": client_token
      },
      data: ''
    }).then(function(response) {

        $scope.positions = response.data.positions;

      }, function(response) {
        alert('Failed: ' + response);
      });
  }

  function getEncryptedKey(apikey) {

          return $http({
            method: 'GET',
            url: urlRoot + "/session/encryptionKey",
            headers: {
                "X-IG-API-KEY": apikey,
                "Content-Type": "application/json; charset=UTF-8",
                "Accept": "application/json; charset=UTF-8"
            },
            data: ''
          });
  }
});



/*
Copyright 2016 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/
